using AgriEnergyConnect3.Data;
using AgriEnergyConnect3.Models;
using AgriEnergyConnect3.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// 1) EF Core + LocalDB
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// 2) Identity with roles
builder.Services
    .AddDefaultIdentity<ApplicationUser>(opts => { opts.SignIn.RequireConfirmedAccount = false; })
    .AddRoles<IdentityRole>()
    .AddEntityFrameworkStores<ApplicationDbContext>();

builder.Services.AddControllersWithViews();

var app = builder.Build();

// 3) Seed roles & users
using (var scope = app.Services.CreateScope())
{
    var roleMgr = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
    var userMgr = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
    var ctx = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

    ctx.Database.Migrate();

    // a) Ensure roles exist
    foreach (var role in new[] { "Farmer", "Employee" })
        if (!await roleMgr.RoleExistsAsync(role))
            await roleMgr.CreateAsync(new IdentityRole(role));

    // b) Create demo Employee
    var empEmail = "employee@demo.com";
    if (await userMgr.FindByEmailAsync(empEmail) == null)
    {
        var emp = new ApplicationUser { UserName = empEmail, Email = empEmail, FullName = "Demo Employee" };
        await userMgr.CreateAsync(emp, "Demo@1234");
        await userMgr.AddToRoleAsync(emp, "Employee");
    }

    // c) Create demo Farmer + sample products
    var farmEmail = "farmer@demo.com";
    if (await userMgr.FindByEmailAsync(farmEmail) == null)
    {
        var farm = new ApplicationUser { UserName = farmEmail, Email = farmEmail, FullName = "Demo Farmer" };
        await userMgr.CreateAsync(farm, "Demo@1234");
        await userMgr.AddToRoleAsync(farm, "Farmer");

        // seed products
        ctx.Products.AddRange(new[]
        {
            new Product { Name="Organic Tomatoes", Category="Vegetable", ProductionDate=DateTime.Today.AddDays(-5), FarmerId=farm.Id },
            new Product { Name="Free-range Eggs",  Category="Poultry",   ProductionDate=DateTime.Today.AddDays(-2), FarmerId=farm.Id }
        });
        await ctx.SaveChangesAsync();
    }
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

// MVC route + Razor Pages (for Identity UI)
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
app.MapRazorPages();

app.Run();
