﻿using AgriEnergyConnect3.Data;
using AgriEnergyConnect3.Models;
using AgriEnergyConnect3.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AgriEnergyConnect3.Controllers
{
    [Authorize(Roles = "Employee")]
    public class EmployeesController : Controller
    {
        private readonly UserManager<ApplicationUser> _userMgr;
        private readonly ApplicationDbContext _ctx;

        public EmployeesController(UserManager<ApplicationUser> userMgr, ApplicationDbContext ctx)
        {
            _userMgr = userMgr;
            _ctx = ctx;
        }

        // List all farmers
        public async Task<IActionResult> Farmers()
        {
            var farmers = await _userMgr.GetUsersInRoleAsync("Farmer");
            return View(farmers);
        }

        // Show form to add a farmer
        public IActionResult CreateFarmer() => View();

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateFarmer(CreateFarmerViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);

            var user = new ApplicationUser
            {
                UserName = vm.Email,
                Email = vm.Email,
                FullName = vm.FullName
            };
            var result = await _userMgr.CreateAsync(user, vm.Password);
            if (result.Succeeded)
            {
                await _userMgr.AddToRoleAsync(user, "Farmer");
                return RedirectToAction(nameof(Farmers));
            }
            foreach (var e in result.Errors)
                ModelState.AddModelError("", e.Description);
            return View(vm);
        }

        // View & filter products for a given farmer
        public async Task<IActionResult> Products(string farmerId, DateTime? start, DateTime? end, string category)
        {
            if (farmerId == null) return BadRequest();
            var query = _ctx.Products
                .Where(p => p.FarmerId == farmerId);

            if (start.HasValue)
                query = query.Where(p => p.ProductionDate >= start.Value);
            if (end.HasValue)
                query = query.Where(p => p.ProductionDate <= end.Value);
            if (!string.IsNullOrWhiteSpace(category))
                query = query.Where(p => p.Category == category);

            var products = await query.Include(p => p.Farmer).ToListAsync();
            ViewBag.FarmerName = (await _userMgr.FindByIdAsync(farmerId)).FullName;
            return View(products);
        }
    }
}
