﻿using AgriEnergyConnect3.Data;
using AgriEnergyConnect3.Models;
using AgriEnergyConnect3.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AgriEnergyConnect3.Controllers
{
    [Authorize(Roles = "Farmer")]
    public class FarmersController : Controller
    {
        private readonly ApplicationDbContext _ctx;
        private readonly UserManager<ApplicationUser> _userMgr;

        public FarmersController(ApplicationDbContext ctx, UserManager<ApplicationUser> userMgr)
        {
            _ctx = ctx;
            _userMgr = userMgr;
        }

        // Show current farmer's products
        public async Task<IActionResult> Index()
        {
            var user = await _userMgr.GetUserAsync(User);
            var products = await _ctx.Products
                              .Where(p => p.FarmerId == user.Id)
                              .ToListAsync();
            return View(products);
        }

        // GET: add a product
        public IActionResult Create() => View();

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProductViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);

            var user = await _userMgr.GetUserAsync(User);
            var p = new Product
            {
                Name = vm.Name,
                Category = vm.Category,
                ProductionDate = vm.ProductionDate,
                FarmerId = user.Id
            };
            _ctx.Products.Add(p);
            await _ctx.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}
