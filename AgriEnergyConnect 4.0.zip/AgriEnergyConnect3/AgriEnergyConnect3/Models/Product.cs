﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AgriEnergyConnect3.Models
{
    public class Product
    {
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Name { get; set; }

        [Required, StringLength(50)]
        public string Category { get; set; }

        [DataType(DataType.Date)]
        public DateTime ProductionDate { get; set; }

        // FK back to the farmer (ApplicationUser.Id)
        [Required]
        public string FarmerId { get; set; }

        [ForeignKey(nameof(FarmerId))]
        public ApplicationUser Farmer { get; set; }
    }
}
